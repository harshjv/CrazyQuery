## CrazyQuery

CrazyQuery is an event in Updates 2014.

### Author

[Harsh Vakharia](http://twitter.com/harshjv)