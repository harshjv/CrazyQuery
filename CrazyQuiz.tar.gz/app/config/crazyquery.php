<?php

return array(

    'total_questions' => 10,
    'total_users' => 10,
    'total_time' => 10,
    'correct_multiplier' => 10,
    'incorrect_multiplier' => 2

);